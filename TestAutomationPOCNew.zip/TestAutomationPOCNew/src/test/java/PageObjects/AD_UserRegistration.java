/**
 * 
 */
package PageObjects;

import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import Utils.DBManager;
import Utils.ElementActions;

/**
 * @author Juhi_Saji
 *
 */
public class AD_UserRegistration {
	WebDriver driver;
	
	String rUsername="usernameRegisterPage";
	String rEmail="emailRegisterPage";
	String rPass="passwordRegisterPage";
	String rPassCnfirm="confirm_passwordRegisterPage";
	String agreeChcbox="i_agree";
	String regstrBtn="register_btn";
	public String title = "(//span[contains(@class,'hi-user')])[last()]";
	String signOut="(//*[text()='Sign out'])[last()]";
	String user=DBManager.testData.get("Reg_UN")+new Random().nextInt(100);
	
	public AD_UserRegistration(WebDriver driver) {
		this.driver = driver;
	}
	
	public void setRegisterDetails() throws InterruptedException {
		
		ElementActions.sendData(driver, By.name(rUsername), user);
		ElementActions.sendData(driver, By.name(rEmail), DBManager.testData.get("Reg_Email"));
		ElementActions.sendData(driver, By.name(rPass), DBManager.testData.get("Reg_Pass"));
		ElementActions.sendData(driver, By.name(rPassCnfirm), DBManager.testData.get("PasswordConfirm"));
		ElementActions.dynamicClick(driver, By.name(agreeChcbox));
		ElementActions.dynamicClick(driver, By.id(regstrBtn));
	}
	
	public String verifyTitle(String username) {
		ElementActions.performVisibleWait(driver, By.xpath(title));
		Assert.assertEquals(driver.findElement(By.xpath(title)).getText(), user);
		return username;

	}
	
	public void signOut() throws InterruptedException {
		ElementActions.dynamicClick(driver, By.xpath(title));
		ElementActions.dynamicClick(driver, By.xpath(signOut));
	}
	
	public void verifySignOut() throws InterruptedException {
		ElementActions.pause(2000);
		Assert.assertEquals(driver.findElement(By.xpath(title)).getText(), "hello");
	}
}
